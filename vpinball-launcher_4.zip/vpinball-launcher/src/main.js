const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

const DATA_FILE = path.join(app.getPath('userData'), 'tables.json');

const DEFAULT_DATA = {
  settings: {
    exePath: 'C:\\RetroBat\\emulators\\vpinball\\vpinballx64.exe',
    wheelPath: '',
  },
  categories: ['Classic', 'Modern', 'Originals', 'Favorites', 'WIP'],
  tables: []
};

function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    }
  } catch (e) { console.error('Failed to load data:', e); }
  return JSON.parse(JSON.stringify(DEFAULT_DATA));
}

function saveData(data) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (e) { console.error('Failed to save data:', e); return false; }
}

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#0a0a0f',
    frame: false,
    icon: path.join(__dirname, '..', 'assets', 'icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    }
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

// Window controls
ipcMain.on('win-minimize', () => mainWindow?.minimize());
ipcMain.on('win-maximize', () => { mainWindow?.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize(); });
ipcMain.on('win-close',    () => mainWindow?.close());

ipcMain.handle('load-data', () => loadData());
ipcMain.handle('save-data', (_, data) => saveData(data));

ipcMain.handle('launch-table', (_, { exePath, tablePath }) => {
  try {
    const os = require('os');
    const batPath = path.join(os.tmpdir(), 'vpinball_launch.bat');
    // Correct VPinball X syntax: -LessCPUthreads -ExtMinimized -play "tablepath"
    const batContent = `@echo off\n"${exePath}" -LessCPUthreads -ExtMinimized -play "${tablePath}"\n`;
    fs.writeFileSync(batPath, batContent, 'utf8');

    console.log('Launch bat contents:', batContent.trim());

    const proc = spawn('cmd.exe', ['/c', batPath], {
      detached: true,
      stdio: 'ignore',
      cwd: path.dirname(exePath),
    });
    proc.unref();
    return { ok: true, cmd: batContent.trim() };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle('browse-vpx', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Select VPX Table File',
    filters: [
      { name: 'Visual Pinball Tables', extensions: ['vpx', 'vpt'] },
      { name: 'All Files', extensions: ['*'] }
    ],
    properties: ['openFile']
  });
  return result.canceled ? null : result.filePaths[0];
});

ipcMain.handle('browse-vpx-multi', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Select VPX Table Files (hold Ctrl/Shift for multiple)',
    filters: [
      { name: 'Visual Pinball Tables', extensions: ['vpx', 'vpt'] },
      { name: 'All Files', extensions: ['*'] }
    ],
    properties: ['openFile', 'multiSelections']
  });
  return result.canceled ? [] : result.filePaths;
});

ipcMain.handle('browse-folder', async (_, title) => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: title || 'Select Folder',
    properties: ['openDirectory']
  });
  return result.canceled ? null : result.filePaths[0];
});

ipcMain.handle('browse-exe', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Select VPinball Executable',
    defaultPath: 'C:\\RetroBat\\emulators\\vpinball',
    filters: [
      { name: 'Executable', extensions: ['exe'] },
      { name: 'All Files', extensions: ['*'] }
    ],
    properties: ['openFile']
  });
  return result.canceled ? null : result.filePaths[0];
});

// Fuzzy wheel matcher — smarter: score based on how well the FILE covers the TABLE name words
// ignoring publisher/version noise that tables have but wheel files may not
ipcMain.handle('find-wheel', (_, { wheelPath, tableName }) => {
  try {
    if (!wheelPath || !fs.existsSync(wheelPath)) return null;

    const files = fs.readdirSync(wheelPath).filter(f =>
      /\.(png|jpg|jpeg|gif|webp)$/i.test(f)
    );

    // Strip noise: parens, brackets, version numbers, known tags, punctuation
    const normalize = str => str
      .toLowerCase()
      .replace(/\([^)]*\)/g, ' ')       // remove (Williams 1997), (Bally 1998) etc
      .replace(/\[[^\]]*\]/g, ' ')       // remove [4K] etc
      .replace(/\bvr\b/gi, ' ')          // strip VR tag
      .replace(/\bmod\b/gi, ' ')         // strip MOD tag
      .replace(/\bvpw\b/gi, ' ')         // strip VPW tag
      .replace(/\bvp\d*\b/gi, ' ')       // strip VP9, VP10 etc
      .replace(/\bv\d+[\d.]*\b/gi, ' ')  // strip v1.0, v2.1.3 etc
      .replace(/\d+\.\d+[\d.]*/g, ' ')   // strip bare version numbers 1.0.1
      .replace(/[^a-z0-9 ]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    const needle = normalize(tableName);
    const needleWords = new Set(needle.split(' ').filter(w => w.length > 1));

    let best = null;
    let bestScore = -1;

    for (const file of files) {
      const base = normalize(path.basename(file, path.extname(file)));
      const baseWords = new Set(base.split(' ').filter(w => w.length > 1));

      // How many of the FILE's words appear in the table name?
      // We bias toward file covering table (not the other way) since
      // wheel files tend to have shorter, cleaner names
      let matches = 0;
      for (const w of baseWords) {
        if (needleWords.has(w)) matches++;
      }

      if (baseWords.size === 0) continue;

      // Precision: what fraction of the file's words matched
      const precision = matches / baseWords.size;
      // Recall: what fraction of the table's words matched
      const recall = needleWords.size > 0 ? matches / needleWords.size : 0;
      // F-score weighted toward precision (file words matching is more important)
      const score = precision * 0.7 + recall * 0.3;

      // Must have at least 1 real match and decent precision
      if (matches >= 1 && precision >= 0.5 && score > bestScore) {
        bestScore = score;
        best = file;
      }
    }

    return best ? path.join(wheelPath, best) : null;
  } catch (e) {
    console.error('find-wheel error:', e);
    return null;
  }
});

// ─── VPS Database ─────────────────────────────────────────────────────────────
let vpsDb = null;

async function loadVpsDb() {
  if (vpsDb) return vpsDb;
  try {
    const https = require('https');
    const data = await new Promise((resolve, reject) => {
      https.get('https://virtualpinballspreadsheet.github.io/vps-db/db/vpsdb.json', res => {
        let raw = '';
        res.on('data', d => raw += d);
        res.on('end', () => { try { resolve(JSON.parse(raw)); } catch(e) { reject(e); } });
      }).on('error', reject);
    });
    vpsDb = data;
    console.log(`VPS DB loaded: ${vpsDb.length} entries`);
    return vpsDb;
  } catch(e) {
    console.error('VPS DB load failed:', e.message);
    return null;
  }
}

ipcMain.handle('vps-lookup', async (_, tableName) => {
  const db = await loadVpsDb();
  if (!db) return null;

  const norm = s => s.toLowerCase()
    .replace(/\([^)]*\)/g, ' ').replace(/\[[^\]]*\]/g, ' ')
    .replace(/\bvr\b|\bmod\b|\bvpw\b|\bvp\d*\b/gi, ' ')
    .replace(/\bv\d+[\d.]*\b/gi, ' ').replace(/\d+\.\d+[\d.]*/g, ' ')
    .replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();

  const needle = norm(tableName);
  const needleWords = needle.split(' ').filter(w => w.length > 1);

  let best = null, bestScore = 0;
  for (const entry of db) {
    if (!entry.name) continue;
    const haystack = norm(entry.name);
    const haystackWords = haystack.split(' ').filter(w => w.length > 1);
    const matches = needleWords.filter(w => haystackWords.includes(w)).length;
    if (haystackWords.length === 0) continue;
    const score = matches / Math.max(needleWords.length, haystackWords.length);
    if (score > bestScore && score >= 0.5) { bestScore = score; best = entry; }
  }

  if (!best) return null;
  // Extract ROM names from romFiles array if present
  const romNames = (best.romFiles || []).map(r => r.rom || r.name || '').filter(Boolean);
  return {
    name: best.name,
    manufacturer: best.manufacturer || '',
    year: best.year || '',
    type: best.type || '',
    theme: (best.theme || []).join(', '),
    designers: (best.designers || []).join(', '),
    ipdbUrl: best.ipdbUrl || '',
    romNames: romNames,
    romSuggestion: romNames[0] || '',
  };
});

// ─── PINemHi ──────────────────────────────────────────────────────────────────
let pinemhiIniCache = null;
let pinemhiIniCachePath = null;

function loadPinemhiIni(iniPath) {
  if (pinemhiIniCachePath === iniPath && pinemhiIniCache) return pinemhiIniCache;
  try {
    const text = fs.readFileSync(iniPath, 'utf8');
    // map: normalized-table-name -> rom-base (no extension, no version suffix)
    // We store ALL entries so fuzzy match can pick the best version
    const map = {};
    for (const raw of text.split(/\r?\n/)) {
      const line = raw.trim();
      if (!line || line.startsWith(';') || line.startsWith('[')) continue;
      if (!line.includes('=')) continue;
      const eq = line.indexOf('=');
      const name = line.slice(0, eq).trim();
      // Strip .nv extension from ROM value
      const rom = line.slice(eq + 1).trim().replace(/\.nv$/i, '').split(/[\s,]/)[0];
      if (name && rom) map[name.toLowerCase()] = rom.toLowerCase();
    }
    pinemhiIniCache = map;
    pinemhiIniCachePath = iniPath;
    console.log('PINemHi ini loaded: ' + Object.keys(map).length + ' entries');
    return map;
  } catch(e) {
    console.error('loadPinemhiIni error:', e.message);
    return null;
  }
}

function normName(s) {
  // Strip parens content (versions, manufacturers), tags, punctuation
  return s.toLowerCase()
    .replace(/\([^)]*\)/g, ' ')
    .replace(/\[[^\]]*\]/g, ' ')
    .replace(/\bvr\b|\bmod\b|\bvpw\b/gi, ' ')
    .replace(/\bv\d+[\d.]*\b/gi, ' ')
    .replace(/\d+\.\d+[\d.]*/g, ' ')
    .replace(/[^a-z0-9 ]/g, ' ')
    .replace(/\s+/g, ' ').trim();
}

function fuzzyMatchIni(iniMap, wheelFile, tableName) {
  // Use wheel filename as primary (already clean), fall back to table name
  const sourceName = wheelFile
    ? path.basename(wheelFile, path.extname(wheelFile))
    : tableName;
  const needle = normName(sourceName);
  const needleWords = needle.split(' ').filter(w => w.length > 1);
  if (needleWords.length === 0) return null;

  let bestRom = null, bestScore = 0;
  for (const [iniName, rom] of Object.entries(iniMap)) {
    // Normalize the ini name — this strips version numbers from parens too
    const hay = normName(iniName);
    const hayWords = hay.split(' ').filter(w => w.length > 1);
    if (hayWords.length === 0) continue;

    const matches = needleWords.filter(w => hayWords.includes(w)).length;
    if (matches === 0) continue;

    // How much of the INI entry's words did we match?
    const precision = matches / hayWords.length;
    // How much of our search words matched?
    const recall = matches / needleWords.length;
    // F-score: weight precision higher since ini names are clean
    const score = precision * 0.6 + recall * 0.4;

    // Require at least 50% precision to avoid false matches
    if (score > bestScore && precision >= 0.5) {
      bestScore = score;
      bestRom = rom;
    }
  }
  console.log('PINemHi match for "' + sourceName + '": ' + bestRom + ' (score=' + bestScore.toFixed(2) + ')');
  return bestRom;
}

ipcMain.handle('pinemhi-scores', (_, { pinemhiFolder, wheelFile, tableName, romOverride }) => {
  try {
    if (!pinemhiFolder || !fs.existsSync(pinemhiFolder)) {
      return { ok: false, error: 'PINemHi folder not found: ' + pinemhiFolder };
    }
    const iniPath = path.join(pinemhiFolder, 'pinemhi.ini');
    if (!fs.existsSync(iniPath)) {
      return { ok: false, error: 'pinemhi.ini not found in: ' + pinemhiFolder };
    }
    const top10Dir = path.join(pinemhiFolder, 'PINemHi LeaderBoard', 'TOP10_Personal');
    if (!fs.existsSync(top10Dir)) {
      return { ok: false, error: 'TOP10_Personal not found at: ' + top10Dir };
    }
    const iniMap = loadPinemhiIni(iniPath);
    if (!iniMap) return { ok: false, error: 'Could not parse pinemhi.ini' };

    // Use manual ROM override if set, otherwise fuzzy match from ini
    const rom = (romOverride && romOverride.trim())
      ? romOverride.trim().toLowerCase().replace(/\.nv$/i, '')
      : fuzzyMatchIni(iniMap, wheelFile, tableName);
    if (!rom) return { ok: false, error: 'No INI match for "' + tableName + '"', unsupported: true };

    const files = fs.readdirSync(top10Dir).filter(f => /\.txt$/i.test(f));
    const romLower = rom.toLowerCase();
    // Get the root prefix — everything before the first underscore: tftc_400 -> tftc
    const romRoot = romLower.split('_')[0];

    const scoreFile = files.find(f => f.toLowerCase().replace('.txt','') === romLower)
                  || files.find(f => f.toLowerCase().startsWith(romLower))
                  || (romRoot.length > 1 && files.find(f => f.toLowerCase().startsWith(romRoot)));

    if (!scoreFile) {
      console.log('No score file for rom "' + rom + '" (root: "' + romRoot + '") in ' + top10Dir);
      console.log('Available: ' + files.join(', '));
      return { ok: false, error: 'No score file for ROM "' + rom + '" — play it first!', unsupported: true };
    }
    const content = fs.readFileSync(path.join(top10Dir, scoreFile), 'utf8').trim();
    if (!content) return { ok: false, error: 'No scores recorded yet' };
    const lower = content.toLowerCase();
    if (lower.includes('not supported') || lower.includes('no support')) {
      return { ok: false, error: 'Not in PINemHi leaderboard database', unsupported: true };
    }
    return { ok: true, rom, file: scoreFile, scores: content };
  } catch(e) {
    return { ok: false, error: e.message };
  }
});

// ─── Scan folder for VPX files ────────────────────────────────────────────────
ipcMain.handle('scan-vpx-folder', (_, folderPath) => {
  try {
    if (!folderPath || !fs.existsSync(folderPath)) return { ok: false, error: 'Folder not found' };
    const files = fs.readdirSync(folderPath)
      .filter(f => /\.(vpx|vpt)$/i.test(f))
      .map(f => path.join(folderPath, f));
    return { ok: true, files };
  } catch(e) {
    return { ok: false, error: e.message };
  }
});

