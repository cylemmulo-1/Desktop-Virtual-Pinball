const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  loadData:       ()        => ipcRenderer.invoke('load-data'),
  saveData:       (data)    => ipcRenderer.invoke('save-data', data),
  launchTable:    (args)    => ipcRenderer.invoke('launch-table', args),
  browseVpx:      ()        => ipcRenderer.invoke('browse-vpx'),
  browseVpxMulti: ()        => ipcRenderer.invoke('browse-vpx-multi'),
  browseFolder:   (title)   => ipcRenderer.invoke('browse-folder', title),
  browseExe:      ()        => ipcRenderer.invoke('browse-exe'),
  findWheel:      (args)    => ipcRenderer.invoke('find-wheel', args),
  vpsLookup:      (name)    => ipcRenderer.invoke('vps-lookup', name),
  pinemhiScores:  (args)    => ipcRenderer.invoke('pinemhi-scores', args),
  scanVpxFolder:  (folder)  => ipcRenderer.invoke('scan-vpx-folder', folder),
  winMinimize:    ()        => ipcRenderer.send('win-minimize'),
  winMaximize:    ()        => ipcRenderer.send('win-maximize'),
  winClose:       ()        => ipcRenderer.send('win-close'),
});
