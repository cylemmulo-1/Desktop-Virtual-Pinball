'use strict';

// ─── Palettes & Icons ────────────────────────────────────────────────────────
const PALETTES = [
  ['#1a0a2e','#6a00cc'],
  ['#0a1a2e','#005faa'],
  ['#0a2e10','#006622'],
  ['#2e1a0a','#994400'],
  ['#2e0a0a','#aa0022'],
  ['#1a2e2a','#006655'],
  ['#2a2a0a','#888800'],
  ['#1a1a1a','#555577'],
];

const ICONS = ['🎯','🎱','⚡','🔮','🚀','🎪','👾','🏆','🎭','🦁','🤖','🌙','🔥','💎','🎲','🧲','🦅','🌀','🎠','⚙️'];

// ─── State ────────────────────────────────────────────────────────────────────
let state = {
  tables: [],
  categories: [],
  settings: { exePath: 'C:\\RetroBat\\emulators\\vpinball\\vpinballx64.exe', wheelPath: '', fontSize: 13, pinemhiFolder: '', tableFolder: '' },
  scores: [
    { table: '', score: '', initials: '' },
    { table: '', score: '', initials: '' },
    { table: '', score: '', initials: '' },
    { table: '', score: '', initials: '' },
    { table: '', score: '', initials: '' },
    { table: '', score: '', initials: '' },
  ],
  activeCategory: 'All Tables',
  selected: null,
  multiSelected: new Set(), // ids of multi-selected tables
  search: '',
  sort: 'name',
  view: 'grid',
  modal: null,
  showSettings: false,
  toast: null,
  wheelCache: {},
  pinemhiCache: {},
  vpsCache: {},
  recentlyPlayed: [],
  deletedPaths: [],
};

let nextId = 1;

// ─── Init ─────────────────────────────────────────────────────────────────────
async function init() {
  const data = await window.api.loadData();
  state.tables = data.tables || [];
  state.categories = data.categories || ['Classic','Modern','Originals','Favorites','WIP'];
  state.settings = data.settings || state.settings;
  state.recentlyPlayed = data.recentlyPlayed || [];
  state.scores = data.scores || state.scores;
  state.deletedPaths = data.deletedPaths || [];
  nextId = state.tables.reduce((m, t) => Math.max(m, t.id || 0), 0) + 1;
  render();
  resolveVisibleWheels();
  // Only resolve wheels for visible tables on startup — rest load on demand
  resolveVisibleWheels();
}

// ─── Persistence ──────────────────────────────────────────────────────────────
async function persist() {
  await window.api.saveData({
    settings: state.settings,
    categories: state.categories,
    tables: state.tables,
    recentlyPlayed: state.recentlyPlayed,
    scores: state.scores,
    deletedPaths: state.deletedPaths,
  });
}

// ─── Wheel resolution ─────────────────────────────────────────────────────────
let wheelRenderTimer = null;

function scheduleRender() {
  // Batch wheel-triggered renders — only re-render once per 150ms max
  if (wheelRenderTimer) return;
  wheelRenderTimer = setTimeout(() => {
    wheelRenderTimer = null;
    render();
  }, 150);
}

async function resolveWheel(table) {
  if (state.wheelCache[table.id] !== undefined) return;
  state.wheelCache[table.id] = null; // mark as in-progress (not undefined)
  const result = await window.api.findWheel({
    wheelPath: state.settings.wheelPath,
    tableName: table.name,
  });
  state.wheelCache[table.id] = result;
  scheduleRender(); // batch renders instead of one per wheel
}

// Only resolve wheels for tables currently visible in the grid
function resolveVisibleWheels() {
  const visible = getFiltered();
  for (const t of visible) {
    if (state.wheelCache[t.id] === undefined) resolveWheel(t);
  }
  if (state.selected) {
    const sel = state.tables.find(t => t.id === state.selected);
    if (sel && state.wheelCache[sel.id] === undefined) resolveWheel(sel);
  }
}

// ─── Filtered tables ──────────────────────────────────────────────────────────
function getFiltered() {
  let t = state.tables;
  if (state.activeCategory === 'Favorites') {
    t = t.filter(x => x.favorite);
  } else if (state.activeCategory !== 'All Tables') {
    t = t.filter(x => x.category === state.activeCategory);
  }
  if (state.search.trim()) {
    const s = state.search.toLowerCase();
    t = t.filter(x =>
      x.name.toLowerCase().includes(s) ||
      (x.manufacturer||'').toLowerCase().includes(s) ||
      (x.category||'').toLowerCase().includes(s)
    );
  }
  const copy = [...t];
  if (state.sort === 'name')  copy.sort((a,b) => a.name.localeCompare(b.name));
  if (state.sort === 'year')  copy.sort((a,b) => (b.year||0) - (a.year||0));
  if (state.sort === 'maker') copy.sort((a,b) => (a.manufacturer||'').localeCompare(b.manufacturer||''));
  if (state.sort === 'plays')  copy.sort((a,b) => (b.playCount||0) - (a.playCount||0));
  if (state.sort === 'recent') copy.sort((a,b) => (b.lastPlayed||0) - (a.lastPlayed||0));
  if (state.sort === 'added')  copy.sort((a,b) => (b.addedAt||0) - (a.addedAt||0));
  return copy;
}

function countForCat(cat) {
  if (cat === 'All Tables') return state.tables.length;
  return state.tables.filter(t => t.category === cat).length;
}

// ─── Toast ────────────────────────────────────────────────────────────────────
let toastTimer = null;
function showToast(msg, type = '') {
  if (toastTimer) clearTimeout(toastTimer);
  state.toast = { msg, type };
  render();
  toastTimer = setTimeout(() => { state.toast = null; render(); }, 2200);
}

// ─── Launch ───────────────────────────────────────────────────────────────────
async function launchTable(table) {
  if (!table.tablePath) { showToast('No table file set', 'error'); return; }
  const result = await window.api.launchTable({
    exePath: state.settings.exePath,
    tablePath: table.tablePath,
  });
  if (result.ok) {
    showToast('▶ LAUNCHING: ' + table.name);
    const now = Date.now();
    // Update play count and last played on the table record
    const idx = state.tables.findIndex(t => t.id === table.id);
    if (idx !== -1) {
      state.tables[idx] = {
        ...state.tables[idx],
        playCount: (state.tables[idx].playCount || 0) + 1,
        lastPlayed: now,
      };
    }
    // Track recently played
    state.recentlyPlayed = [
      { id: table.id, name: table.name, launchedAt: now },
      ...state.recentlyPlayed.filter(r => r.id !== table.id)
    ].slice(0, 20);
    await persist();
  } else {
    showToast('Launch failed: ' + result.error, 'error');
  }
}

// ─── Favorite toggle ──────────────────────────────────────────────────────────
async function toggleFavorite(table) {
  const idx = state.tables.findIndex(t => t.id === table.id);
  if (idx === -1) return;
  const isFav = state.tables[idx].favorite;
  state.tables[idx] = { ...state.tables[idx], favorite: !isFav };
  showToast(isFav ? 'Removed from Favorites' : '⭐ Added to Favorites');
  await persist();
  render();
}

// ─── Sync table folder ───────────────────────────────────────────────────────
async function scanTableFolder() {
  let folder = state.settings.tableFolder;
  if (!folder) {
    folder = await window.api.browseFolder('Select VPX Tables Folder');
    if (!folder) return;
    state.settings.tableFolder = folder;
    await persist();
  }
  showToast('Scanning folder...');
  const result = await window.api.scanVpxFolder(folder);
  if (!result.ok) { showToast('Scan failed: ' + result.error, 'error'); return; }

  const onDisk = new Set(result.files.map(f => f.toLowerCase()));
  const defaultCat = state.categories[0] || '';

  // Remove tables whose files no longer exist on disk
  const before = state.tables.length;
  state.tables = state.tables.filter(t => {
    if (!t.tablePath) return true; // keep manually-added tables with no path
    return onDisk.has(t.tablePath.toLowerCase());
  });
  const removed = before - state.tables.length;
  if (state.selected && !state.tables.find(t => t.id === state.selected)) {
    state.selected = null;
  }

  // Add files not already in the library
  const existingPaths = new Set(state.tables.map(t => t.tablePath?.toLowerCase()));
  let added = 0;
  for (const filePath of result.files) {
    if (existingPaths.has(filePath.toLowerCase())) continue;
    const t = {
      id: nextId++, name: nameFromPath(filePath),
      year: '', manufacturer: '', category: defaultCat,
      tablePath: filePath, icon: ICONS[Math.floor(Math.random() * ICONS.length)],
      palette: Math.floor(Math.random() * PALETTES.length), notes: '',
      playCount: 0, lastPlayed: null, favorite: false, romName: '',
      addedAt: Date.now(),
    };
    state.tables.push(t);
    resolveWheel(t);
    added++;
  }

  await persist();
  const parts = [];
  if (added > 0) parts.push(`+${added} added`);
  if (removed > 0) parts.push(`-${removed} removed`);
  showToast(parts.length > 0 ? `SYNCED: ${parts.join(', ')}` : 'Library up to date');
  render();
}
// Extract a clean display name from a file path
function nameFromPath(filePath) {
  // Get basename without extension: "Medieval Madness (Williams 1997) VPW 1.0.1 VR.vpx" -> "Medieval Madness (Williams 1997) VPW 1.0.1 VR"
  const base = filePath.replace(/\\/g, '/').split('/').pop().replace(/\.[^.]+$/, '');
  return base;
}

function timeAgo(ts) {
  const diff = Math.floor((Date.now() - ts) / 1000);
  if (diff < 60) return 'just now';
  if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
  if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
  if (diff < 604800) return Math.floor(diff / 86400) + 'd ago';
  return Math.floor(diff / 604800) + 'w ago';
}

// ─── Modal helpers ────────────────────────────────────────────────────────────
function openAddTable() {
  state.modal = {
    type: 'table',
    isEdit: false,
    data: {
      name: '', year: new Date().getFullYear(), manufacturer: '',
      category: state.activeCategory !== 'All Tables' ? state.activeCategory : (state.categories[0] || ''),
      tablePath: '', icon: '🎯', palette: 0, notes: ''
    }
  };
  render();
}

function openEditTable(t) {
  state.modal = { type: 'table', isEdit: true, data: { ...t } };
  render();
}

function openSettings() {
  state.showSettings = true; render();
}

function closeModal() { state.modal = null; render(); }
function closeSettings() { state.showSettings = false; render(); }

// ─── Save table ───────────────────────────────────────────────────────────────
async function saveTable() {
  const d = state.modal.data;
  // Auto-name from file path if left blank
  if (!d.name.trim() && d.tablePath) {
    d.name = nameFromPath(d.tablePath);
  }
  if (!d.name.trim()) { showToast('Table name or file required', 'error'); return; }
  if (state.modal.isEdit) {
    const idx = state.tables.findIndex(t => t.id === d.id);
    if (idx !== -1) {
      state.tables[idx] = { ...d };
      delete state.wheelCache[d.id];
      resolveWheel(state.tables[idx]);
    }
    showToast('TABLE UPDATED');
  } else {
    const t = { ...d, id: nextId++, name: d.name.trim(), addedAt: Date.now() };
    state.tables.push(t);
    state.selected = t.id;
    resolveWheel(t);
    showToast('TABLE ADDED');
  }
  state.modal = null;
  await persist();
  render();
}

// ─── Bulk import ──────────────────────────────────────────────────────────────
async function importMultiple() {
  const paths = await window.api.browseVpxMulti();
  if (!paths || paths.length === 0) return;

  const defaultCat = state.activeCategory !== 'All Tables' ? state.activeCategory : (state.categories[0] || '');
  let added = 0;

  for (const filePath of paths) {
    // Skip duplicates (same tablePath already exists)
    if (state.tables.some(t => t.tablePath === filePath)) continue;
    const t = {
      id: nextId++,
      name: nameFromPath(filePath),
      year: '',
      manufacturer: '',
      category: defaultCat,
      tablePath: filePath,
      icon: ICONS[Math.floor(Math.random() * ICONS.length)],
      palette: Math.floor(Math.random() * PALETTES.length),
      notes: ''
    };
    state.tables.push(t);
    resolveWheel(t);
    added++;
  }

  if (added > 0) {
    await persist();
    showToast(`IMPORTED ${added} TABLE${added !== 1 ? 'S' : ''}`);
    render();
  } else {
    showToast('No new tables to import', '');
  }
}

// ─── Delete table ─────────────────────────────────────────────────────────────
async function deleteTable(id) {
  if (!confirm('Remove this table from the launcher?')) return;
  state.tables = state.tables.filter(t => t.id !== id);
  if (state.selected === id) state.selected = null;
  showToast('TABLE REMOVED');
  await persist();
  render();
}

// ─── Category management ──────────────────────────────────────────────────────
async function addCategory(name) {
  name = name.trim();
  if (!name) return;
  if (state.categories.includes(name)) { showToast('Category exists', 'error'); return; }
  state.categories.push(name);
  showToast('CATEGORY ADDED');
  await persist();
  render();
}

async function deleteCategory(cat) {
  const hasTables = state.tables.some(t => t.category === cat);
  if (hasTables) {
    const ok = confirm(`"${cat}" has tables in it. Delete anyway and move them to the first category?`);
    if (!ok) return;
    const fallback = state.categories.filter(c => c !== cat)[0] || '';
    state.tables = state.tables.map(t => t.category === cat ? { ...t, category: fallback } : t);
  }
  state.categories = state.categories.filter(c => c !== cat);
  if (state.activeCategory === cat) state.activeCategory = 'All Tables';
  showToast('CATEGORY REMOVED');
  await persist();
  render();
}

// ─── Settings save ────────────────────────────────────────────────────────────
async function saveSettings() {
  // Invalidate wheel cache when wheelPath changes
  state.wheelCache = {};
  state.tables.forEach(t => resolveWheel(t));
  await persist();
  showToast('SETTINGS SAVED');
  closeSettings();
}

// ─── DOM helpers ──────────────────────────────────────────────────────────────
function el(tag, props, ...children) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (k === 'class') { e.className = v; }
    else if (k === 'style' && typeof v === 'object') { Object.assign(e.style, v); }
    else if (k.startsWith('on') && typeof v === 'function') { e.addEventListener(k.slice(2).toLowerCase(), v); }
    else if (k === '_html') { e.innerHTML = v; }
    else { e.setAttribute(k, v); }
  }
  for (const c of children) {
    if (c == null || c === false) continue;
    e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return e;
}

function txt(s) { return document.createTextNode(s); }

// ─── Art helpers ──────────────────────────────────────────────────────────────
function makeArtBg(palette) {
  const [c1, c2] = PALETTES[palette % PALETTES.length];
  const d = el('div', { class: 'card-art-bg', style: { background: `linear-gradient(160deg,${c1},${c2})` } });
  return d;
}

function makeArtEl(table, forDetail = false) {
  const wrap = el('div', { class: forDetail ? 'detail-art' : 'card-art' });
  wrap.appendChild(makeArtBg(table.palette));
  const wheel = state.wheelCache[table.id];
  if (wheel) {
    const img = el('img', { src: 'file://' + wheel, alt: table.name });
    img.addEventListener('error', () => { state.wheelCache[table.id] = null; render(); });
    wrap.appendChild(img);
  } else {
    const fb = el('div', { class: 'card-art-fallback' });
    fb.appendChild(el('span', { class: 'card-art-icon' }, table.icon || '🎯'));
    wrap.appendChild(fb);
  }
  return wrap;
}

// ─── Scoreboard ───────────────────────────────────────────────────────────────
function renderScoreboard() {
  const slots = state.scores.map((s, i) => {
    const isEmpty = !s.table && !s.score;
    return el('div', {
      class: 'score-slot' + (isEmpty ? ' score-empty' : ''),
      onClick: () => openScoreEdit(i),
      title: 'Click to edit'
    },
      el('div', { class: 'score-rank' }, '#' + (i + 1)),
      el('div', { class: 'score-body' },
        el('div', { class: 'score-table' }, s.table || 'Click to set'),
        el('div', { class: 'score-num' }, s.score ? formatScore(s.score) : '—')
      ),
      s.initials ? el('div', { class: 'score-initials' }, s.initials) : null
    );
  });
  return el('div', { class: 'scoreboard' },
    el('div', { class: 'scoreboard-label' }, '🏆 SCORES TO BEAT'),
    el('div', { class: 'scoreboard-slots' }, ...slots)
  );
}

function formatScore(s) {
  const n = parseInt(String(s).replace(/,/g, ''));
  if (isNaN(n)) return s;
  return n.toLocaleString();
}

function openScoreEdit(idx) {
  state.modal = { type: 'score', idx, data: { ...state.scores[idx] } };
  render();
}

function renderScoreModal() {
  const d = state.modal.data;
  const idx = state.modal.idx;

  let tableInp, scoreInp, initialsInp;

  const save = async () => {
    state.scores[idx] = { table: d.table, score: d.score, initials: d.initials };
    state.modal = null;
    await persist();
    render();
  };

  const clear = async () => {
    state.scores[idx] = { table: '', score: '', initials: '' };
    state.modal = null;
    await persist();
    render();
  };

  const backdrop = el('div', { class: 'modal-backdrop', onClick: closeModal });
  const modal = el('div', { class: 'modal' },
    el('div', { class: 'modal-title' }, 'SCORE SLOT #' + (idx + 1)),
    el('div', { class: 'field' },
      el('label', null, 'TABLE NAME'),
      (tableInp = el('input', { type: 'text', placeholder: 'e.g. Medieval Madness', value: d.table || '' }))
    ),
    el('div', { class: 'field' },
      el('label', null, 'HIGH SCORE'),
      (scoreInp = el('input', { type: 'text', placeholder: 'e.g. 1,234,567,890', value: d.score || '' }))
    ),
    el('div', { class: 'field' },
      el('label', null, 'INITIALS (optional)'),
      (initialsInp = el('input', { type: 'text', placeholder: 'e.g. AAA', maxlength: '4', value: d.initials || '', style: { textTransform: 'uppercase', width: '6em' } }))
    ),
    el('div', { class: 'modal-actions' },
      el('button', { class: 'btn danger', onClick: clear }, 'CLEAR'),
      el('button', { class: 'btn ghost', onClick: closeModal }, 'CANCEL'),
      el('button', { class: 'btn primary', onClick: save }, 'SAVE')
    )
  );

  tableInp.addEventListener('input', e => { d.table = e.target.value; });
  scoreInp.addEventListener('input', e => { d.score = e.target.value; });
  initialsInp.addEventListener('input', e => { d.initials = e.target.value.toUpperCase(); });
  modal.addEventListener('click', e => e.stopPropagation());
  backdrop.appendChild(modal);
  return backdrop;
}

// ─── VPS Scan All ─────────────────────────────────────────────────────────────
async function vpsScanAll() {
  // Only scan tables missing manufacturer or year
  const targets = state.tables.filter(t => !t.manufacturer || !t.year);
  if (targets.length === 0) { showToast('All tables already have VPS data'); return; }

  showToast(`VPS: scanning ${targets.length} tables...`);
  let updated = 0, notFound = 0;

  for (const table of targets) {
    const result = await window.api.vpsLookup(table.name);
    if (!result) { notFound++; continue; }
    const idx = state.tables.findIndex(t => t.id === table.id);
    if (idx === -1) continue;
    state.tables[idx] = {
      ...state.tables[idx],
      manufacturer: result.manufacturer || state.tables[idx].manufacturer,
      year: result.year || state.tables[idx].year,
    };
    updated++;
  }

  await persist();
  showToast(`VPS done: ${updated} updated, ${notFound} not found`);
  render();
}

function renderBulkBar() {
  const count = state.multiSelected.size;
  if (count === 0) return null;

  let catSel;
  const bar = el('div', { class: 'bulk-bar' },
    el('span', { class: 'bulk-count' }, `${count} TABLE${count !== 1 ? 'S' : ''} SELECTED`),
    el('button', { class: 'btn sm ghost', onClick: () => {
      // Select all visible
      const filtered = getFiltered();
      state.multiSelected = new Set(filtered.map(t => t.id));
      render();
    }}, 'SELECT ALL'),
    el('button', { class: 'btn sm ghost', onClick: () => {
      state.multiSelected = new Set();
      render();
    }}, 'CLEAR'),
    el('div', { class: 'bulk-sep' }),
    el('span', { class: 'bulk-label' }, 'MOVE TO:'),
    (catSel = el('select', { class: 'sort-select' },
      ...state.categories.map(c => el('option', { value: c }, c))
    )),
    el('button', { class: 'btn sm primary', onClick: async () => {
      const cat = catSel.value;
      let moved = 0;
      state.tables = state.tables.map(t => {
        if (state.multiSelected.has(t.id)) { moved++; return { ...t, category: cat }; }
        return t;
      });
      state.multiSelected = new Set();
      await persist();
      showToast(`MOVED ${moved} TABLE${moved !== 1 ? 'S' : ''} TO ${cat}`);
      render();
    }}, 'MOVE'),
    el('div', { class: 'bulk-sep' }),
    el('button', { class: 'btn sm danger', onClick: async () => {
      if (!confirm(`Remove ${count} table${count !== 1 ? 's' : ''} from the launcher?`)) return;
      const ids = state.multiSelected;
      state.tables = state.tables.filter(t => !ids.has(t.id));
      if (ids.has(state.selected)) state.selected = null;
      state.multiSelected = new Set();
      await persist();
      showToast(`REMOVED ${count} TABLES`);
      render();
    }}, 'REMOVE ALL'),
  );
  return bar;
}

// ─── Context menu ─────────────────────────────────────────────────────────────
let contextMenu = null;

function showContextMenu(e, table) {
  e.preventDefault();
  e.stopPropagation();
  removeContextMenu();

  const menu = el('div', { class: 'ctx-menu' },
    el('div', { class: 'ctx-item', onClick: () => { launchTable(table); removeContextMenu(); } }, '▶ Launch'),
    el('div', { class: 'ctx-sep' }),
    el('div', { class: 'ctx-item', onClick: () => { openEditTable(table); removeContextMenu(); } }, '✏ Edit'),
    el('div', { class: 'ctx-item', onClick: () => { toggleFavorite(table); removeContextMenu(); } }, table.favorite ? '☆ Remove from Favorites' : '⭐ Add to Favorites'),
    el('div', { class: 'ctx-sep' }),
    el('div', { class: 'ctx-item ctx-danger', onClick: () => { removeContextMenu(); deleteTable(table.id); } }, '✕ Remove')
  );

  // Position near cursor, keep on screen
  const x = Math.min(e.clientX, window.innerWidth - 180);
  const y = Math.min(e.clientY, window.innerHeight - 160);
  menu.style.left = x + 'px';
  menu.style.top = y + 'px';

  document.body.appendChild(menu);
  contextMenu = menu;

  // Close on any outside click
  setTimeout(() => document.addEventListener('click', removeContextMenu, { once: true }), 10);
}

function removeContextMenu() {
  if (contextMenu) { contextMenu.remove(); contextMenu = null; }
}

// ─── Render functions ─────────────────────────────────────────────────────────

function renderHeader() {
  return el('div', { class: 'titlebar' },
    el('div', { class: 'titlebar-left' },
      el('div', { class: 'logo' }, 'VP', el('span', null, 'LAUNCHER')),
      el('button', { class: 'btn sm ghost', onClick: openSettings }, '⚙ SETTINGS'),
      el('button', { class: 'btn sm ghost', onClick: scanTableFolder }, '📁 SCAN FOLDER'),
      el('button', { class: 'btn sm ghost', onClick: vpsScanAll }, '🔍 VPS SCAN ALL'),
      el('button', { class: 'btn sm ghost', onClick: importMultiple }, '⬇ IMPORT FILES'),
      el('button', { class: 'btn sm primary', onClick: openAddTable }, '+ ADD TABLE'),
    ),
    el('div', { class: 'titlebar-drag' }),
    el('div', { class: 'titlebar-right' },
      el('button', { class: 'wc-btn', title: 'Minimize', onClick: () => window.api.winMinimize() }, '─'),
      el('button', { class: 'wc-btn', title: 'Maximize', onClick: () => window.api.winMaximize() }, '□'),
      el('button', { class: 'wc-btn close', title: 'Close', onClick: () => window.api.winClose() }, '✕'),
    )
  );
}

function renderSidebar() {
  const allCats = ['All Tables', ...state.categories];
  const catItems = allCats.map(cat => {
    const item = el('div', {
      class: 'cat-item' + (state.activeCategory === cat ? ' active' : ''),
      onClick: () => { state.activeCategory = cat; state.selected = null; render(); }
    },
      el('span', null, cat),
      el('span', { class: 'cat-count' }, String(countForCat(cat)))
    );
    if (cat !== 'All Tables') {
      const del = el('button', {
        class: 'cat-del', title: 'Delete category',
        onClick: (e) => { e.stopPropagation(); deleteCategory(cat); }
      }, '✕');
      item.appendChild(del);
    }
    return item;
  });

  // Recently played section
  const recentItems = state.recentlyPlayed.slice(0, 10).map(r => {
    const table = state.tables.find(t => t.id === r.id);
    if (!table) return null;
    const ago = timeAgo(r.launchedAt);
    const item = el('div', {
      class: 'cat-item recent-item' + (state.selected === r.id ? ' active' : ''),
      onClick: () => {
        state.activeCategory = 'All Tables';
        state.selected = r.id;
        render();
      }
    },
      el('span', { class: 'recent-name', title: table.name }, table.name),
      el('span', { class: 'recent-ago' }, ago)
    );
    return item;
  }).filter(Boolean);

  // Inline add-category input
  let catInputEl;
  const addRow = el('div', { class: 'add-cat-input-row' },
    (catInputEl = el('input', {
      class: 'add-cat-input', type: 'text',
      placeholder: 'New category...',
      onKeydown: (e) => { if (e.key === 'Enter') { addCategory(catInputEl.value); catInputEl.value = ''; } }
    })),
    el('button', { class: 'btn sm', onClick: () => { addCategory(catInputEl.value); catInputEl.value = ''; } }, '+')
  );

  return el('div', { class: 'sidebar' },
    el('div', { class: 'sidebar-scroll' },
      el('div', { class: 'sidebar-section' },
        el('div', { class: 'sidebar-label' }, 'Categories'),
        ...catItems
      ),
      recentItems.length > 0 ? el('div', { class: 'sidebar-section' },
        el('div', { class: 'sidebar-label' }, 'Recently Played'),
        ...recentItems
      ) : null
    ),
    el('div', { class: 'sidebar-footer' }, addRow)
  );
}

function renderToolbar(count) {
  const searchWrap = el('div', { class: 'search-wrap' });

  const searchEl = el('input', {
    class: 'search-input', type: 'text',
    placeholder: '🔍 Search tables...',
    value: state.search,
  });
  searchEl.addEventListener('input', (e) => {
    state.search = e.target.value;
    const pos = e.target.selectionStart;
    render();
    const newInput = document.querySelector('.search-input');
    if (newInput) { newInput.focus(); newInput.setSelectionRange(pos, pos); }
  });

  const clearBtn = el('button', {
    class: 'search-clear' + (state.search ? '' : ' hidden'),
    onClick: () => { state.search = ''; render(); document.querySelector('.search-input')?.focus(); }
  }, '✕');

  searchWrap.appendChild(searchEl);
  searchWrap.appendChild(clearBtn);

  const sortEl = el('select', {
    class: 'sort-select',
    onChange: (e) => { state.sort = e.target.value; render(); }
  });
  [
    ['name',   'NAME'],
    ['year',   'YEAR'],
    ['maker',  'MAKER'],
    ['plays',  'MOST PLAYED'],
    ['recent', 'LAST PLAYED'],
    ['added',  'NEWLY ADDED'],
  ].forEach(([v, l]) => {
    const o = el('option', { value: v }, l);
    if (state.sort === v) o.selected = true;
    sortEl.appendChild(o);
  });

  return el('div', { class: 'toolbar' },
    searchWrap, sortEl,
    el('span', { class: 'table-count' }, `${count} TABLE${count !== 1 ? 'S' : ''}`),
    el('div', { class: 'toolbar-right' },
      el('button', { class: 'view-btn' + (state.view === 'grid' ? ' active' : ''), onClick: () => { state.view = 'grid'; render(); } }, '⊞'),
      el('button', { class: 'view-btn' + (state.view === 'list' ? ' active' : ''), onClick: () => { state.view = 'list'; render(); } }, '☰'),
    )
  );
}

function renderCard(table) {
  const isMulti = state.multiSelected.has(table.id);
  const isSel = state.selected === table.id && !isMulti;
  const card = el('div', {
    class: 'table-card' + (isSel ? ' selected' : '') + (isMulti ? ' multi-selected' : ''),
    onClick: (e) => {
      if (e.ctrlKey || e.metaKey) {
        // Ctrl+click = toggle multi-select
        const next = new Set(state.multiSelected);
        next.has(table.id) ? next.delete(table.id) : next.add(table.id);
        state.multiSelected = next;
        state.selected = null;
      } else {
        state.multiSelected = new Set();
        state.selected = state.selected === table.id ? null : table.id;
      }
      render();
    },
    onDblclick: () => { state.multiSelected = new Set(); launchTable(table); },
    onContextmenu: (e) => { state.selected = table.id; render(); showContextMenu(e, table); },
  },
    makeArtEl(table),
    el('div', { class: 'card-cat-badge' }, table.category),
    table.favorite ? el('div', { class: 'card-fav-badge' }, '⭐') : null,
    table.playCount ? el('div', { class: 'card-plays-badge' }, '▶ ' + table.playCount) : null,
    isMulti ? el('div', { class: 'card-check' }, '✓') : null,
    el('div', { class: 'card-info' },
      el('div', { class: 'card-name' }, table.name),
      el('div', { class: 'card-meta' }, (table.year || '') + (table.manufacturer ? ' · ' + table.manufacturer : ''))
    )
  );
  return card;
}

function renderListRow(table) {
  const artSm = el('div', { class: 'list-art-sm' });
  artSm.appendChild(makeArtBg(table.palette));
  const wheel = state.wheelCache[table.id];
  if (wheel) {
    const img = el('img', { src: 'file://' + wheel, alt: table.name });
    img.style.position = 'relative';
    img.style.zIndex = '1';
    artSm.appendChild(img);
  } else {
    artSm.appendChild(el('span', { style: { position: 'relative', zIndex: '1', fontSize: '15px' } }, table.icon || '🎯'));
  }

  const isMulti = state.multiSelected.has(table.id);
  const isSel = state.selected === table.id && !isMulti;
  return el('div', {
    class: 'list-row' + (isSel ? ' selected' : '') + (isMulti ? ' multi-selected' : ''),
    onClick: (e) => {
      if (e.ctrlKey || e.metaKey) {
        const next = new Set(state.multiSelected);
        next.has(table.id) ? next.delete(table.id) : next.add(table.id);
        state.multiSelected = next;
        state.selected = null;
      } else {
        state.multiSelected = new Set();
        state.selected = state.selected === table.id ? null : table.id;
      }
      render();
    },
    onDblclick: () => { state.multiSelected = new Set(); launchTable(table); },
    onContextmenu: (e) => { state.selected = table.id; render(); showContextMenu(e, table); },
  },
    artSm,
    isMulti ? el('span', { class: 'list-check' }, '✓') : (table.favorite ? el('span', { style: { fontSize: '0.85em' } }, '⭐') : null),
    el('span', { class: 'list-name' }, table.name),
    el('span', { class: 'list-maker' }, table.manufacturer || ''),
    el('span', { class: 'list-year' }, String(table.year || '')),
    table.playCount ? el('span', { class: 'list-plays' }, '▶' + table.playCount) : null,
    el('span', { class: 'list-cat' }, table.category || '')
  );
}

async function fetchVps(table) {
  if (state.vpsCache[table.id] !== undefined) return;
  state.vpsCache[table.id] = null; // loading
  const result = await window.api.vpsLookup(table.name);
  state.vpsCache[table.id] = result; // null if not found
  render();
}

async function fetchPinemhi(table) {
  if (!state.settings.pinemhiFolder) return;
  if (state.pinemhiCache[table.id] !== undefined) return;
  state.pinemhiCache[table.id] = null;
  const wheel = state.wheelCache[table.id];
  const result = await window.api.pinemhiScores({
    pinemhiFolder: state.settings.pinemhiFolder,
    wheelFile: wheel || '',
    tableName: table.name,
    romOverride: table.romName || '', // manual ROM name takes priority
  });
  state.pinemhiCache[table.id] = result;
  render();
}

function renderDetailPanel(table) {
  if (!table) {
    return el('div', { class: 'detail-panel' },
      el('div', { class: 'empty-panel' },
        el('div', { class: 'ep-icon' }, '🎱'),
        el('div', { class: 'ep-msg' }, 'SELECT A TABLE\nTO VIEW DETAILS\n\nDOUBLE-CLICK\nTO LAUNCH')
      )
    );
  }

  const launchBtn = el('button', {
    class: 'launch-btn',
    onClick: () => launchTable(table)
  }, '▶  LAUNCH');
  if (!table.tablePath) launchBtn.disabled = true;

  // PINemHi scores section
  let scoresSection = null;
  if (state.settings.pinemhiFolder) {
    const cached = state.pinemhiCache[table.id];
    if (cached === undefined) {
      // Not yet fetched — trigger fetch and show loading
      fetchPinemhi(table);
      scoresSection = el('div', { class: 'pinemhi-section' },
        el('div', { class: 'pinemhi-label' }, '🏆 HIGH SCORES'),
        el('div', { class: 'pinemhi-loading' }, 'Loading...')
      );
    } else if (cached === null) {
      scoresSection = el('div', { class: 'pinemhi-section' },
        el('div', { class: 'pinemhi-label' }, '🏆 HIGH SCORES'),
        el('div', { class: 'pinemhi-loading' }, 'Loading...')
      );
    } else if (!cached.ok) {
      // Hide section entirely for unsupported tables — not worth showing an error
      if (!cached.unsupported) {
        scoresSection = el('div', { class: 'pinemhi-section' },
          el('div', { class: 'pinemhi-label' }, '🏆 HIGH SCORES'),
          el('div', { class: 'pinemhi-error' }, cached.error),
          el('button', { class: 'btn sm ghost', style: { marginTop: '6px' }, onClick: () => {
            delete state.pinemhiCache[table.id];
            fetchPinemhi(table);
            render();
          }}, '↺ RETRY')
        );
      }
    } else {
      // Parse the raw text output into lines and display
      const lines = cached.scores.split('\n').map(l => l.trim()).filter(Boolean);
      scoresSection = el('div', { class: 'pinemhi-section' },
        el('div', { class: 'pinemhi-label' }, `🏆 HIGH SCORES  ·  ${cached.file}`),
        el('div', { class: 'pinemhi-scores' },
          ...lines.map((line, i) => el('div', { class: 'pinemhi-line' + (i === 0 ? ' pinemhi-line-first' : '') }, line))
        ),
        el('button', { class: 'btn sm ghost', style: { marginTop: '6px' }, onClick: () => {
          delete state.pinemhiCache[table.id];
          fetchPinemhi(table);
          render();
        }}, '↺ REFRESH')
      );
    }
  }

  return el('div', { class: 'detail-panel' },
    makeArtEl(table, true),
    el('div', { class: 'detail-scroll' },
      el('div', { class: 'detail-body' },
        el('div', { class: 'detail-title' }, table.name),
        el('div', { class: 'detail-sub' }, [table.manufacturer, table.year].filter(Boolean).join(' · ')),
        el('hr', { class: 'detail-divider' }),
        el('div', { class: 'detail-row' }, el('span', { class: 'lbl' }, 'CATEGORY'), el('span', { class: 'val' }, table.category || '—')),
        el('div', { class: 'detail-row' }, el('span', { class: 'lbl' }, 'YEAR'), el('span', { class: 'val' }, String(table.year || '—'))),
        el('div', { class: 'detail-row' }, el('span', { class: 'lbl' }, 'MAKER'), el('span', { class: 'val' }, table.manufacturer || '—')),
        (() => {
          // Show ROM name — manual override takes priority, then pinemhi detected
          if (table.romName) {
            return el('div', { class: 'detail-row' },
              el('span', { class: 'lbl' }, 'ROM'),
              el('span', { class: 'val', style: { color: 'var(--orange)' } }, table.romName)
            );
          }
          const cached = state.pinemhiCache[table.id];
          if (cached && cached.ok && cached.rom) {
            return el('div', { class: 'detail-row' },
              el('span', { class: 'lbl' }, 'ROM'),
              el('span', { class: 'val', style: { color: 'var(--muted)' } }, cached.rom)
            );
          }
          return null;
        })(),
        el('div', { class: 'detail-row' }, el('span', { class: 'lbl' }, 'PLAYS'), el('span', { class: 'val' }, String(table.playCount || 0))),
        table.lastPlayed ? el('div', { class: 'detail-row' }, el('span', { class: 'lbl' }, 'LAST PLAYED'), el('span', { class: 'val' }, timeAgo(table.lastPlayed))) : null,
        table.notes ? el('div', { class: 'detail-notes' }, table.notes) : null,
        el('div', { class: 'detail-exe' }, table.tablePath ? '▶ ' + table.tablePath : 'No file path set — click Edit'),
        launchBtn,
        el('div', { class: 'detail-actions' },
          el('button', {
            class: 'btn' + (table.favorite ? ' primary' : ''),
            onClick: () => toggleFavorite(table),
            title: table.favorite ? 'Remove from Favorites' : 'Add to Favorites'
          }, table.favorite ? '⭐ FAV' : '☆ FAV'),
          el('button', { class: 'btn', onClick: () => openEditTable(table) }, '✏ EDIT'),
          el('button', { class: 'btn danger', onClick: () => deleteTable(table.id) }, '✕ REMOVE')
        ),
        scoresSection
      )
    )
  );
}

function renderEmptyGrid() {
  return el('div', { class: 'empty-grid' },
    el('div', { class: 'eg-icon' }, '🎯'),
    el('div', { class: 'eg-msg' }, state.search ? 'NO TABLES MATCH YOUR SEARCH' : 'NO TABLES YET'),
    el('button', { class: 'btn primary', style: { marginTop: '10px' }, onClick: openAddTable }, '+ ADD TABLE')
  );
}

// ─── Table modal ──────────────────────────────────────────────────────────────
function renderTableModal() {
  const d = state.modal.data;
  const isEdit = state.modal.isEdit;

  function mkInput(lbl, key, type = 'text', ph = '') {
    const inp = el('input', { type, placeholder: ph, value: d[key] != null ? String(d[key]) : '', 'data-key': key });
    inp.addEventListener('input', e => { d[key] = type === 'number' ? (parseInt(e.target.value) || e.target.value) : e.target.value; });
    return el('div', { class: 'field' }, el('label', null, lbl), inp);
  }

  const catSel = el('select');
  state.categories.forEach(c => {
    const o = el('option', { value: c }, c);
    if (d.category === c) o.selected = true;
    catSel.appendChild(o);
  });
  catSel.addEventListener('change', e => { d.category = e.target.value; });

  // Table file path with browse — auto-fills name if blank
  let pathInp, nameInp;
  const pathRow = el('div', { class: 'browse-row' },
    (pathInp = el('input', {
      type: 'text', placeholder: 'C:\\path\\to\\table.vpx',
      value: d.tablePath || ''
    })),
    el('button', { class: 'btn sm ghost', onClick: async () => {
      const p = await window.api.browseVpx();
      if (p) {
        d.tablePath = p;
        pathInp.value = p;
        // Auto-fill name from filename if name field is still empty
        if (!d.name.trim() && nameInp) {
          d.name = nameFromPath(p);
          nameInp.value = d.name;
        }
      }
    }}, 'BROWSE')
  );
  pathInp.addEventListener('input', e => { d.tablePath = e.target.value; });

  // Icon picker
  const iconPicker = el('div', { class: 'art-picker' });
  ICONS.forEach(icon => {
    const btn = el('div', { class: 'art-opt' + (d.icon === icon ? ' sel' : '') }, icon);
    btn.addEventListener('click', () => {
      d.icon = icon;
      iconPicker.querySelectorAll('.art-opt').forEach(b => b.classList.remove('sel'));
      btn.classList.add('sel');
    });
    iconPicker.appendChild(btn);
  });

  // Palette picker
  const palPicker = el('div', { class: 'art-picker' });
  PALETTES.forEach((p, i) => {
    const btn = el('div', {
      class: 'pal-opt' + (d.palette === i ? ' sel' : ''),
      style: { background: `linear-gradient(135deg,${p[0]},${p[1]})` },
      title: `Color ${i + 1}`
    });
    btn.addEventListener('click', () => {
      d.palette = i;
      palPicker.querySelectorAll('.pal-opt').forEach(b => b.classList.remove('sel'));
      btn.classList.add('sel');
    });
    palPicker.appendChild(btn);
  });

  // Notes
  const notesEl = el('textarea', { placeholder: 'Optional notes...', style: { height: '56px' } }, d.notes || '');
  notesEl.addEventListener('input', e => { d.notes = e.target.value; });

  const backdrop = el('div', { class: 'modal-backdrop', onClick: closeModal });

  // Build name field manually so we can grab the input ref for auto-fill from browse
  nameInp = el('input', { type: 'text', placeholder: 'Leave blank to use filename', value: d.name || '' });
  nameInp.addEventListener('input', e => { d.name = e.target.value; });

  // VPS lookup button — fills maker/year/type from Virtual Pinball Spreadsheet
  const vpsStatus = el('span', { style: { fontSize: '0.77em', color: 'var(--muted)', marginLeft: '6px' } });
  const vpsBtn = el('button', { class: 'btn sm ghost', style: { marginLeft: '4px' }, onClick: async () => {
    const lookupName = d.name.trim() || nameFromPath(d.tablePath || '');
    if (!lookupName) { vpsStatus.textContent = 'Enter a name first'; return; }
    vpsBtn.textContent = '...';
    vpsBtn.disabled = true;
    vpsStatus.textContent = 'Searching VPS...';
    const result = await window.api.vpsLookup(lookupName);
    vpsBtn.textContent = 'VPS LOOKUP';
    vpsBtn.disabled = false;
    if (!result) { vpsStatus.textContent = 'No match found'; return; }
    // Fill fields
    if (result.manufacturer) { d.manufacturer = result.manufacturer; const inp = modal.querySelector('[data-key="manufacturer"]'); if (inp) inp.value = result.manufacturer; }
    if (result.year) { d.year = result.year; const inp = modal.querySelector('[data-key="year"]'); if (inp) inp.value = result.year; }
    if (result.designers && !d.notes) { d.notes = result.designers ? 'Designers: ' + result.designers : ''; notesEl.value = d.notes; }
    vpsStatus.style.color = 'var(--success)';
    vpsStatus.textContent = `✓ Matched: ${result.name} (${result.year}) ${result.type}`;
  }}, 'VPS LOOKUP');

  const nameField = el('div', { class: 'field' },
    el('label', null, 'TABLE NAME'),
    el('div', { style: { display: 'flex', alignItems: 'center', gap: '6px' } }, nameInp, vpsBtn),
    vpsStatus
  );

  // ROM name override for PINemHi
  const romInp = el('input', { type: 'text', placeholder: 'e.g. tftc_400  (leave blank for auto-detect)', value: d.romName || '' });
  romInp.addEventListener('input', e => { d.romName = e.target.value.trim(); });

  const modal = el('div', { class: 'modal' },
    el('div', { class: 'modal-title' }, isEdit ? 'EDIT TABLE' : 'ADD TABLE'),
    nameField,
    el('div', { class: 'field-row' },
      mkInput('MANUFACTURER', 'manufacturer', 'text', 'e.g. Williams'),
      mkInput('YEAR', 'year', 'number', '1990')
    ),
    el('div', { class: 'field' }, el('label', null, 'CATEGORY'), catSel),
    el('div', { class: 'field' }, el('label', null, 'TABLE FILE (.VPX)'), pathRow),
    el('div', { class: 'field' }, el('label', null, 'ROM NAME (PINEMHI OVERRIDE)'), romInp),
    el('div', { class: 'field' }, el('label', null, 'ICON (FALLBACK)'), iconPicker),
    el('div', { class: 'field' }, el('label', null, 'COLOR SCHEME'), palPicker),
    el('div', { class: 'field' }, el('label', null, 'NOTES'), notesEl),
    el('div', { class: 'modal-actions' },
      el('button', { class: 'btn ghost', onClick: closeModal }, 'CANCEL'),
      el('button', { class: 'btn primary', onClick: saveTable }, isEdit ? 'SAVE CHANGES' : 'ADD TABLE')
    )
  );
  modal.addEventListener('click', e => e.stopPropagation());
  backdrop.appendChild(modal);
  return backdrop;
}

// ─── Settings panel ───────────────────────────────────────────────────────────
function renderSettings() {
  const s = state.settings;

  let exeInp, wheelInp;

  const exeRow = el('div', { class: 'browse-row' },
    (exeInp = el('input', { type: 'text', value: s.exePath || '', placeholder: 'C:\\path\\to\\vpinballx64.exe' })),
    el('button', { class: 'btn sm ghost', onClick: async () => {
      const p = await window.api.browseExe();
      if (p) { s.exePath = p; exeInp.value = p; }
    }}, 'BROWSE')
  );
  exeInp.addEventListener('input', e => { s.exePath = e.target.value; });

  const wheelRow = el('div', { class: 'browse-row' },
    (wheelInp = el('input', { type: 'text', value: s.wheelPath || '', placeholder: 'C:\\path\\to\\wheel images\\' })),
    el('button', { class: 'btn sm ghost', onClick: async () => {
      const p = await window.api.browseFolder('Select Wheel Images Folder');
      if (p) { s.wheelPath = p; wheelInp.value = p; }
    }}, 'BROWSE')
  );
  wheelInp.addEventListener('input', e => { s.wheelPath = e.target.value; });

  const cancelBtn = el('button', { class: 'btn ghost sm' }, 'CANCEL');
  cancelBtn.addEventListener('click', closeSettings);

  const saveBtn = el('button', { class: 'btn primary sm' }, 'SAVE');
  saveBtn.addEventListener('click', saveSettings);

  const settingsHeader = el('div', { class: 'settings-header' },
    el('div', { class: 'settings-title' }, '⚙ SETTINGS'),
    el('div', { style: { flex: '1' } }),
    cancelBtn,
    saveBtn,
    el('div', { style: { width: '12px' } }),
    el('button', { class: 'wc-btn', title: 'Minimize', onClick: () => window.api.winMinimize() }, '─'),
    el('button', { class: 'wc-btn', title: 'Maximize', onClick: () => window.api.winMaximize() }, '□'),
    el('button', { class: 'wc-btn close', title: 'Close', onClick: () => window.api.winClose() }, '✕'),
  );
  settingsHeader.style.webkitAppRegion = 'no-drag';

  return el('div', { class: 'settings-panel' },
    settingsHeader,
    el('div', { class: 'settings-body' },
      el('div', { class: 'settings-section' },
        el('div', { class: 'settings-section-title' }, 'Tables'),
        el('div', { class: 'field' },
          el('label', null, 'TABLE FOLDER (AUTO-SCAN)'),
          (() => {
            let inp;
            const row = el('div', { class: 'browse-row' },
              (inp = el('input', { type: 'text', value: s.tableFolder || '', placeholder: 'C:\\RetroBat\\roms\\vpinball\\' })),
              el('button', { class: 'btn sm ghost', onClick: async () => {
                const p = await window.api.browseFolder('Select VPX Tables Folder');
                if (p) { s.tableFolder = p; inp.value = p; }
              }}, 'BROWSE')
            );
            inp.addEventListener('input', e => { s.tableFolder = e.target.value; });
            return row;
          })()
        ),
        el('div', { style: { fontSize: '10px', color: 'var(--muted)' } },
          'Used by the 📁 SCAN FOLDER button to auto-import new .vpx files.'
        )
      ),
      el('div', { class: 'settings-section' },
        el('div', { class: 'settings-section-title' }, 'Executable'),
        el('div', { class: 'field' },
          el('label', null, 'VPINBALL EXE PATH'),
          exeRow,
          el('div', { style: { fontSize: '10px', color: 'var(--muted)', marginTop: '4px' } },
            'Default: C:\\RetroBat\\emulators\\vpinball\\vpinballx64.exe'
          )
        )
      ),
      el('div', { class: 'settings-section' },
        el('div', { class: 'settings-section-title' }, 'Artwork'),
        el('div', { class: 'field' },
          el('label', null, 'WHEEL IMAGES FOLDER'),
          wheelRow,
          el('div', { style: { fontSize: '10px', color: 'var(--muted)', marginTop: '4px' } },
            'Fuzzy-matched by table name — version numbers and extra tags are stripped automatically.'
          )
        )
      ),
      el('div', { class: 'settings-section' },
        el('div', { class: 'settings-section-title' }, 'PINemHi'),
        el('div', { class: 'field' },
          el('label', null, 'PINEMHI FOLDER'),
          (() => {
            let inp;
            const row = el('div', { class: 'browse-row' },
              (inp = el('input', { type: 'text', value: s.pinemhiFolder || '', placeholder: 'C:\\PINemHi\\' })),
              el('button', { class: 'btn sm ghost', onClick: async () => {
                const p = await window.api.browseFolder('Select PINemHi Folder');
                if (p) { s.pinemhiFolder = p; inp.value = p; }
              }}, 'BROWSE')
            );
            inp.addEventListener('input', e => { s.pinemhiFolder = e.target.value; });
            return row;
          })()
        ),
        el('div', { style: { fontSize: '10px', color: 'var(--muted)' } },
          'Folder containing pinemhi.ini. Scores are read from the TOP10_Personal subfolder automatically.'
        )
      ),
      el('div', { class: 'settings-section' },
        el('div', { class: 'settings-section-title' }, 'Appearance'),
        el('div', { class: 'field' },
          el('label', null, 'FONT SIZE'),
          (() => {
            const sizeOut = el('span', { style: { fontSize: '12px', color: 'var(--text)', minWidth: '30px', display: 'inline-block' } }, (s.fontSize || 13) + 'px');
            const slider = el('input', { type: 'range', min: '10', max: '20', step: '1', value: String(s.fontSize || 13), style: { flex: '1' } });
            slider.addEventListener('input', e => {
              s.fontSize = parseInt(e.target.value);
              sizeOut.textContent = s.fontSize + 'px';
              document.documentElement.style.fontSize = s.fontSize + 'px';
            });
            const row = el('div', { style: { display: 'flex', alignItems: 'center', gap: '12px' } }, slider, sizeOut);
            return row;
          })()
        ),
      ),
      el('div', { class: 'settings-section' },
        el('div', { class: 'settings-section-title' }, 'Launch Command'),
        el('div', { style: { fontSize: '11px', color: 'var(--muted)', background: 'var(--bg3)', padding: '10px', border: '1px solid var(--border)', borderRadius: 'var(--radius)', fontFamily: 'inherit' } },
          'vpinballx64.exe -LessCPUthreads -ExtMinimized -play "C:\\path\\to\\table.vpx"'
        )
      )
    )
  );
}

// ─── Main render ──────────────────────────────────────────────────────────────
function render() {
  document.documentElement.style.fontSize = (state.settings.fontSize || 13) + 'px';

  const root = document.getElementById('app');
  const prevScroll = skipScrollRestore ? null : (document.querySelector('.grid-area')?.scrollTop ?? 0);
  skipScrollRestore = false;
  root.innerHTML = '';

  if (state.showSettings) {
    const wrapper = el('div', { class: 'app' });
    wrapper.appendChild(renderSettings());
    root.appendChild(wrapper);
    return;
  }

  const filtered = getFiltered();
  const selectedTable = state.tables.find(t => t.id === state.selected);

  const gridContent = filtered.length === 0 ? renderEmptyGrid() :
    state.view === 'grid'
      ? el('div', { class: 'grid' }, ...filtered.map(renderCard))
      : el('div', { class: 'list' }, ...filtered.map(renderListRow));

  const gridArea = el('div', { class: 'grid-area' }, gridContent);

  const bulkBar = renderBulkBar();

  const app = el('div', { class: 'app' },
    renderHeader(),
    renderScoreboard(),
    el('div', { class: 'layout' },
      renderSidebar(),
      el('div', { class: 'main' },
        renderToolbar(filtered.length),
        gridArea
      ),
      renderDetailPanel(selectedTable)
    ),
    bulkBar
  );

  root.appendChild(app);

  // Restore scroll position (skipped when keyboard navigating)
  if (prevScroll !== null) gridArea.scrollTop = prevScroll;

  if (state.modal?.type === 'table') {
    root.appendChild(renderTableModal());
  }
  if (state.modal?.type === 'score') {
    root.appendChild(renderScoreModal());
  }

  if (state.toast) {
    root.appendChild(el('div', { class: 'toast' + (state.toast.type ? ' ' + state.toast.type : '') }, state.toast.msg));
  }

  // Resolve wheels for newly visible tables (non-blocking, batched)
  resolveVisibleWheels();
}

// ─── Keyboard navigation ──────────────────────────────────────────────────────
let heldKeys = {};
let heldInterval = null;

function getNavDirection() {
  if (heldKeys['ShiftLeft'] || heldKeys['ArrowLeft'] || heldKeys['ArrowUp']) return -1;
  if (heldKeys['ShiftRight'] || heldKeys['ArrowRight'] || heldKeys['ArrowDown']) return 1;
  if (heldKeys['z'] || heldKeys['Z']) return -12;
  if (heldKeys['/']) return 12;
  return 0;
}

function doNav(dir) {
  if (state.modal || state.showSettings) return;
  const filtered = getFiltered();
  if (filtered.length === 0) return;
  const currentIdx = filtered.findIndex(t => t.id === state.selected);
  let nextIdx;
  if (Math.abs(dir) === 1) {
    nextIdx = dir === -1
      ? (currentIdx <= 0 ? filtered.length - 1 : currentIdx - 1)
      : (currentIdx < 0 || currentIdx >= filtered.length - 1 ? 0 : currentIdx + 1);
  } else {
    const PAGE = Math.abs(dir);
    nextIdx = dir < 0
      ? Math.max(0, (currentIdx <= 0 ? 0 : currentIdx) - PAGE)
      : Math.min(filtered.length - 1, (currentIdx < 0 ? 0 : currentIdx) + PAGE);
  }
  if (nextIdx === currentIdx) return;
  state.selected = filtered[nextIdx].id;
  skipScrollRestore = true;
  render();
  scrollSelectedIntoView();
}

function startHeldInterval() {
  if (heldInterval) return;
  heldInterval = setInterval(() => {
    const dir = getNavDirection();
    if (dir === 0) { stopHeldInterval(); return; }
    doNav(dir);
  }, 80); // move every 80ms while held = ~12 per second
}

function stopHeldInterval() {
  if (heldInterval) { clearInterval(heldInterval); heldInterval = null; }
}

function setupKeyboard() {
  document.addEventListener('keydown', (e) => {
    if (['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName)) return;
    if (state.modal || state.showSettings) return;

    // Ctrl+F = focus search
    if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
      e.preventDefault();
      const searchEl = document.querySelector('.search-input');
      if (searchEl) { searchEl.focus(); searchEl.select(); }
      return;
    }

    // Enter to launch
    if (e.key === 'Enter') {
      e.preventDefault();
      if (state.selected) {
        const table = state.tables.find(t => t.id === state.selected);
        if (table) launchTable(table);
      }
      return;
    }

    const navKeys = ['ShiftLeft','ShiftRight','Shift','ArrowLeft','ArrowRight','ArrowUp','ArrowDown','z','Z','/','?'];
    if (!navKeys.includes(e.key) && !['ShiftLeft','ShiftRight'].includes(e.code)) return;

    // Map Shift by location
    const key = e.key === 'Shift'
      ? (e.location === 1 ? 'ShiftLeft' : 'ShiftRight')
      : e.key;

    e.preventDefault();

    if (!heldKeys[key]) {
      heldKeys[key] = true;
      // Move immediately on first press
      const dir = getNavDirection();
      if (dir !== 0) doNav(dir);
      startHeldInterval();
    }
  });

  document.addEventListener('keyup', (e) => {
    const key = e.key === 'Shift'
      ? (e.location === 1 ? 'ShiftLeft' : 'ShiftRight')
      : e.key;
    delete heldKeys[key];
    if (getNavDirection() === 0) stopHeldInterval();
  });

  // Stop if window loses focus
  window.addEventListener('blur', () => { heldKeys = {}; stopHeldInterval(); });
}

let skipScrollRestore = false;

function scrollSelectedIntoView() {
  requestAnimationFrame(() => {
    const sel = document.querySelector('.table-card.selected, .list-row.selected');
    const gridArea = document.querySelector('.grid-area');
    if (!sel || !gridArea) return;

    const selRect = sel.getBoundingClientRect();
    const gridRect = gridArea.getBoundingClientRect();

    // Check if selected item is outside the visible grid area
    if (selRect.bottom > gridRect.bottom) {
      // Scroll down so item is visible with some padding
      gridArea.scrollTop += selRect.bottom - gridRect.bottom + 20;
    } else if (selRect.top < gridRect.top) {
      // Scroll up
      gridArea.scrollTop -= gridRect.top - selRect.top + 20;
    }
  });
}

// ─── Boot ─────────────────────────────────────────────────────────────────────
init();
setupKeyboard();
